# COMP30024 Artificial Intelligence, Semester 1 2023
# Project Part B: Game Playing Agent

from .program import Agent
